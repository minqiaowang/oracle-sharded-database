package oracle.monitor;

public class Install {
    public static void main(String [] args)
    {

    }
}
