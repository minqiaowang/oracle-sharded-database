package oracle.demo;

public class InstallSchema
{
    public static void main(String[] args)
    {
//        "create tablespace set %s datafile size 100m autoextend on;";
//        "create tablespace %s datafile size 100m autoextend on;";
    }
}

