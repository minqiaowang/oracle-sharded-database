/*
** Oracle Sharding Demo
**
** Copyright (c) 2017 Oracle and/or its affiliates. All rights reserved.
** Licensed under the Universal Permissive License v 1.0 as shown at 
**   http://oss.oracle.com/licenses/upl 
*/

package oracle.demo;

public class InstallSchema
{
    public static void main(String[] args)
    {
//        "create tablespace set %s datafile size 100m autoextend on;";
//        "create tablespace %s datafile size 100m autoextend on;";
    }
}

